export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { topic, niche, platform, tone } = req.body;

  if (!topic || !niche || !platform || !tone) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content: `Write 3 unique ${platform} captions for: "${topic}"
Niche: ${niche} | Tone: ${tone}

Rules:
- Include natural emojis throughout each caption
- Include 3–5 relevant hashtags at the end of each caption
- Vary the structure: hook-based, storytelling, direct
- Tone must feel authentically ${tone}
- Optimized for ${platform} engagement

Respond ONLY with a raw JSON array of 3 strings. No markdown, no explanation, no backticks:
["caption1","caption2","caption3"]`,
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`Anthropic API error: ${response.status}`);
    }

    const data = await response.json();
    const raw = data.content[0].text.replace(/```json|```/g, "").trim();
    const captions = JSON.parse(raw);

    return res.status(200).json({ captions });
  } catch (err) {
    console.error("Generate error:", err);
    return res.status(500).json({ error: "Failed to generate captions" });
  }
}
