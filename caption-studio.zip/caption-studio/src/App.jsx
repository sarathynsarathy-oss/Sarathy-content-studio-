import { useState, useEffect } from "react";

const NICHES = ["Fashion", "Food", "Fitness", "Travel", "Business", "Lifestyle"];
const PLATFORMS = ["Instagram", "LinkedIn", "Twitter / X", "TikTok"];
const TONES = ["Aesthetic", "Funny", "Professional", "Motivational", "Storytelling"];

const C = {
  bg: "#F7F6F3",
  white: "#FFFFFF",
  text: "#0C0C0B",
  muted: "#7A7A75",
  mutedLight: "#AEADA7",
  accent: "#0D9E73",
  accentLight: "#E6F5EF",
  accentDark: "#0A7A59",
  border: "#E4E3DF",
  pill: "#F0EFE9",
};

export default function App() {
  const [topic, setTopic] = useState("");
  const [niche, setNiche] = useState("Fashion");
  const [platform, setPlatform] = useState("Instagram");
  const [tone, setTone] = useState("Aesthetic");
  const [captions, setCaptions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(null);
  const [error, setError] = useState("");
  const [dots, setDots] = useState("");

  useEffect(() => {
    if (!loading) { setDots(""); return; }
    const i = setInterval(() => setDots(d => d.length >= 3 ? "" : d + "."), 400);
    return () => clearInterval(i);
  }, [loading]);

  const generate = async () => {
    if (!topic.trim()) { setError("Enter a topic first"); return; }
    setLoading(true);
    setCaptions([]);
    setError("");
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, niche, platform, tone }),
      });
      if (!res.ok) throw new Error("API error");
      const data = await res.json();
      setCaptions(data.captions);
    } catch {
      setError("Something went wrong. Try again.");
    }
    setLoading(false);
  };

  const copy = (text, i) => {
    navigator.clipboard.writeText(text);
    setCopied(i);
    setTimeout(() => setCopied(null), 2000);
  };

  const Pill = ({ label, selected, onClick }) => (
    <button
      onClick={onClick}
      style={{
        padding: "7px 16px",
        borderRadius: "100px",
        border: selected ? `1.5px solid ${C.accent}` : `1px solid ${C.border}`,
        background: selected ? C.accentLight : C.pill,
        color: selected ? C.accentDark : C.muted,
        fontFamily: "Outfit, sans-serif",
        fontSize: "13px",
        fontWeight: selected ? 600 : 400,
        cursor: "pointer",
        transition: "all 0.13s ease",
      }}
    >
      {label}
    </button>
  );

  const Label = ({ text }) => (
    <p style={{
      margin: "0 0 10px 0",
      fontSize: "10.5px",
      fontWeight: 600,
      letterSpacing: "0.1em",
      textTransform: "uppercase",
      color: C.mutedLight,
    }}>{text}</p>
  );

  return (
    <div style={{ fontFamily: "Outfit, sans-serif", background: C.bg, minHeight: "100vh" }}>

      {/* Header */}
      <div style={{
        background: C.white,
        borderBottom: `1px solid ${C.border}`,
        padding: "18px 40px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <div style={{
            width: "34px", height: "34px",
            background: C.accent,
            borderRadius: "9px",
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "#fff", fontSize: "15px",
          }}>✦</div>
          <div>
            <p style={{ margin: 0, fontSize: "16px", fontWeight: 700, color: C.text, letterSpacing: "-0.4px" }}>
              Caption Studio
            </p>
            <p style={{ margin: 0, fontSize: "11px", color: C.mutedLight }}>
              by Sarathy · AI-Powered
            </p>
          </div>
        </div>
        <div style={{
          padding: "6px 14px",
          borderRadius: "100px",
          background: C.accentLight,
          fontSize: "12px",
          fontWeight: 500,
          color: C.accentDark,
        }}>
          Free to use
        </div>
      </div>

      {/* Main */}
      <div style={{ maxWidth: "640px", margin: "0 auto", padding: "48px 24px 80px" }}>

        {/* Hero */}
        <div style={{ marginBottom: "36px" }}>
          <h1 style={{
            margin: "0 0 10px 0",
            fontSize: "36px",
            fontWeight: 700,
            color: C.text,
            letterSpacing: "-1.2px",
            lineHeight: 1.15,
          }}>
            Captions that<br />
            <span style={{ color: C.accent }}>actually convert.</span>
          </h1>
          <p style={{ margin: 0, fontSize: "15px", color: C.muted, lineHeight: 1.6 }}>
            Pick your niche, tone, platform — get 3 scroll-stopping captions in seconds.
          </p>
        </div>

        {/* Topic input */}
        <div style={{
          background: C.white,
          border: `1.5px solid ${error ? "#D85A30" : C.border}`,
          borderRadius: "16px",
          padding: "20px 22px",
          marginBottom: "14px",
          transition: "border-color 0.15s",
        }}>
          <Label text="What's your post about?" />
          <textarea
            value={topic}
            onChange={e => { setTopic(e.target.value); setError(""); }}
            placeholder="e.g. Morning gym session, new café in Chennai, fashion shoot at Marina Beach..."
            style={{
              width: "100%",
              minHeight: "80px",
              border: "none",
              outline: "none",
              resize: "none",
              fontFamily: "Outfit, sans-serif",
              fontSize: "15px",
              color: C.text,
              background: "transparent",
              lineHeight: 1.65,
            }}
          />
          {error && (
            <p style={{ margin: "4px 0 0", fontSize: "12px", color: "#D85A30" }}>{error}</p>
          )}
        </div>

        {/* Selectors */}
        <div style={{
          background: C.white,
          border: `1.5px solid ${C.border}`,
          borderRadius: "16px",
          padding: "22px",
          marginBottom: "14px",
        }}>
          {[
            { label: "Niche", items: NICHES, val: niche, set: setNiche },
            { label: "Platform", items: PLATFORMS, val: platform, set: setPlatform },
            { label: "Tone", items: TONES, val: tone, set: setTone },
          ].map((group, gi) => (
            <div key={group.label} style={{
              marginTop: gi > 0 ? "20px" : 0,
              paddingTop: gi > 0 ? "20px" : 0,
              borderTop: gi > 0 ? `1px solid ${C.border}` : "none",
            }}>
              <Label text={group.label} />
              <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                {group.items.map(item => (
                  <Pill
                    key={item}
                    label={item}
                    selected={group.val === item}
                    onClick={() => group.set(item)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Generate button */}
        <button
          onClick={generate}
          disabled={loading}
          style={{
            width: "100%",
            padding: "17px",
            borderRadius: "14px",
            border: "none",
            background: loading ? "#7ECFB5" : C.accent,
            color: "#fff",
            fontFamily: "Outfit, sans-serif",
            fontSize: "16px",
            fontWeight: 600,
            letterSpacing: "-0.2px",
            cursor: loading ? "not-allowed" : "pointer",
            transition: "background 0.2s",
          }}
        >
          {loading ? `Generating captions${dots}` : "✦  Generate 3 Captions"}
        </button>

        {/* Output */}
        {captions.length > 0 && (
          <div style={{ marginTop: "36px" }}>
            <p style={{
              margin: "0 0 14px",
              fontSize: "10.5px",
              fontWeight: 600,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              color: C.mutedLight,
            }}>
              Generated for {platform} · {niche} · {tone}
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              {captions.map((caption, i) => (
                <div key={i} style={{
                  background: C.white,
                  border: `1.5px solid ${C.border}`,
                  borderRadius: "14px",
                  padding: "20px 20px 16px",
                }}>
                  <div style={{ display: "flex", gap: "12px", alignItems: "flex-start", marginBottom: "14px" }}>
                    <div style={{
                      minWidth: "24px", height: "24px",
                      borderRadius: "50%",
                      background: C.accentLight,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: "11px", fontWeight: 700, color: C.accentDark,
                      marginTop: "2px",
                    }}>{i + 1}</div>
                    <p style={{ margin: 0, fontSize: "14px", lineHeight: 1.8, color: C.text, flex: 1 }}>
                      {caption}
                    </p>
                  </div>
                  <div style={{ paddingLeft: "36px" }}>
                    <button
                      onClick={() => copy(caption, i)}
                      style={{
                        padding: "7px 14px",
                        borderRadius: "8px",
                        border: `1px solid ${copied === i ? C.accent : C.border}`,
                        background: copied === i ? C.accentLight : C.pill,
                        color: copied === i ? C.accentDark : C.muted,
                        fontFamily: "Outfit, sans-serif",
                        fontSize: "12px",
                        fontWeight: 500,
                        cursor: "pointer",
                        transition: "all 0.15s",
                      }}
                    >
                      {copied === i ? "✓ Copied!" : "Copy"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <p style={{ textAlign: "center", marginTop: "18px", fontSize: "12px", color: C.mutedLight }}>
              Not vibing? Hit generate again for fresh ones ✦
            </p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{
        borderTop: `1px solid ${C.border}`,
        padding: "16px 32px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: C.white,
      }}>
        <p style={{ fontSize: "12px", color: C.mutedLight }}>sarathycaption.vercel.app</p>
        <p style={{ fontSize: "12px", color: C.mutedLight }}>
          Built by <span style={{ color: C.accent, fontWeight: 600 }}>N. Sarathy</span>
        </p>
      </div>
    </div>
  );
}
